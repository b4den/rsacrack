#ifndef MPFQ_FIXMP_I386_H_
#define MPFQ_FIXMP_I386_H_

/* MPFQ generated file -- do not edit */

#include <gmp.h>
#include <limits.h>
#ifdef	MPFQ_LAST_GENERATED_TAG
#undef	MPFQ_LAST_GENERATED_TAG
#endif
#define MPFQ_LAST_GENERATED_TAG      fixmp

/* Active handler: Mpfq::fixmp::i386 */
/* Options used:{ features={ gcc_inline_assembly=1, }, tag=fixmp, w=32, } */


#ifdef  __cplusplus
extern "C" {
#endif
#ifdef  __cplusplus
}
#endif

#endif  /* MPFQ_FIXMP_I386_H_ */

/* vim:set ft=cpp: */
