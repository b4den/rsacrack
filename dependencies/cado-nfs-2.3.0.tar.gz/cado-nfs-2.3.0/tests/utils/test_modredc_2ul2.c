#include "cado.h"
#define ARITHMETIC "modredc_2ul2_default.h"
#include "test_mod.c"
